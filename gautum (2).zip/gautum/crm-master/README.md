# crm
A Customer Relation Management System built using Django and MySQL. Its specially built for academy or whoever offers some kind of course and want to have a system where every detail is stored properly such as student all academic details, address, interested course etc. The desk manager can call the student and insert each and every follow up detail of the student. And after the student is enrolled , details of the payment can be inserted.

![alt tag](https://github.com/rahul-connect/crm/blob/master/crm_login.png?raw=true "Description goes here")
![alt tag](https://github.com/rahul-connect/crm/blob/master/crm_home.png?raw=true "Description goes here")

![alt tag](https://github.com/rahul-connect/crm/blob/master/crm_page.png?raw=true "Description goes here")

![alt tag](https://github.com/rahul-connect/crm/blob/master/crm_page2.png?raw=true "Description goes here")

![alt tag](https://github.com/rahul-connect/crm/blob/master/crm_page3.png?raw=true "Description goes here")

![alt tag](https://github.com/rahul-connect/crm/blob/master/crm_page4.png?raw=true "Description goes here")

![alt tag](https://github.com/rahul-connect/crm/blob/master/crm_page5.png?raw=true "Description goes here")

